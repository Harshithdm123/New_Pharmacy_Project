package com.example.myapp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class Expired extends AppCompatActivity {

    private ListView listView;
    private ProgressBar progressBar;
    private ArrayList<String> medicineList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expired);

        listView = findViewById(R.id.listView);
        progressBar = findViewById(R.id.progressBar);
        medicineList = new ArrayList<>();

        new FetchExpiredMedicinesTask().execute();
    }

    private class FetchExpiredMedicinesTask extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(Void... voids) {
            String response = "";
            try {
                URL url = new URL("http://10.0.2.2/aaaaaaaaaaa/get_expired_medicines.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String inputLine;
                StringBuilder content = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    content.append(inputLine);
                }

                in.close();
                conn.disconnect();

                response = content.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressBar.setVisibility(View.GONE);
            try {
                JSONArray jsonArray = new JSONArray(s);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String medicine = "Name: " + jsonObject.getString("name") + ", Expiry: " + jsonObject.getString("expiry_date");
                    medicineList.add(medicine);
                }
                ArrayAdapter<String> adapter = new ArrayAdapter<>(Expired.this, android.R.layout.simple_list_item_1, medicineList);
                listView.setAdapter(adapter);
            } catch (JSONException e) {
                e.printStackTrace();
                Toast.makeText(Expired.this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
