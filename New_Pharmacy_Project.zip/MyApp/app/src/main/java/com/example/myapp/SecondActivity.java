package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    private Button ADDPatientButton;
    private Button StocksactivityButton;
    private Button ExpiredButton;
    private Button SettingsButton;
    private Button ViewpatientButton; // Added ViewpatientButton declaration
    private Button ReportButton; // Added ReportButton declaration

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2); // Ensure this matches your actual layout file name

        // Initialize buttons
        ADDPatientButton = findViewById(R.id.btnInventory);
        StocksactivityButton = findViewById(R.id.btnSales);
        ExpiredButton = findViewById(R.id.btnPrescriptions);
        SettingsButton = findViewById(R.id.btnSettings);
        ViewpatientButton = findViewById(R.id.btnCustomers); // Initialize ViewpatientButton
        ReportButton = findViewById(R.id.btnReports); // Initialize ReportButton

        // Set onClickListener for ADDPatientButton
        ADDPatientButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAddPatientActivity();
            }
        });

        // Set onClickListener for StocksactivityButton
        StocksactivityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openStocksActivity();
            }
        });

        // Set onClickListener for ExpiredButton
        ExpiredButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openExpiredActivity();
            }
        });

        // Set onClickListener for SettingsButton
        SettingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSettingsActivity();
            }
        });

        // Set onClickListener for ViewpatientButton
        ViewpatientButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openViewPatientsActivity();
            }
        });

        // Set onClickListener for ReportButton
        ReportButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openReportsActivity();
            }
        });
    }

    // Function to open AddPatientActivity
    private void openAddPatientActivity() {
        Intent intent = new Intent(SecondActivity.this, AddPatientActivity.class);
        startActivity(intent);
    }

    // Function to open StocksActivity
    private void openStocksActivity() {
        Intent intent = new Intent(SecondActivity.this, StocksActivity.class);
        startActivity(intent);
    }

    // Function to open ExpiredActivity
    private void openExpiredActivity() {
        Intent intent = new Intent(SecondActivity.this, Expired.class);
        startActivity(intent);
    }

    // Function to open SettingsActivity
    private void openSettingsActivity() {
        Intent intent = new Intent(SecondActivity.this, SettingsActivity.class);
        startActivity(intent);
    }

    // Function to open ViewPatientsActivity
    private void openViewPatientsActivity() {
        Intent intent = new Intent(SecondActivity.this, ViewPatientsActivity.class); // Replace with correct ViewPatientsActivity class name
        startActivity(intent);
    }

    // Function to open ReportsActivity
    private void openReportsActivity() {
        Intent intent = new Intent(SecondActivity.this, ReportsActivity.class); // Replace with correct ReportsActivity class name
        startActivity(intent);
    }
}
