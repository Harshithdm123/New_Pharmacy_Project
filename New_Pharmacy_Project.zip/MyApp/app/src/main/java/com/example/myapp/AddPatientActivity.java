package com.example.myapp;

import android.app.DatePickerDialog;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.EditText;
import android.widget.DatePicker;
import android.widget.Button;
import android.view.View;
import android.widget.TextView;
import java.util.Calendar;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AddPatientActivity extends AppCompatActivity {

    private EditText idEditText, nameEditText, ageEditText, dateEditText, addressEditText;
    private Button addButton;
    private TextView patientListTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        idEditText = findViewById(R.id.id_edit_text);
        nameEditText = findViewById(R.id.name_edit_text);
        ageEditText = findViewById(R.id.age_edit_text);
        dateEditText = findViewById(R.id.date_edit_text);
        addressEditText = findViewById(R.id.address_edit_text);
        addButton = findViewById(R.id.button);
        patientListTextView = findViewById(R.id.patient_list);

        // Set current date to the EditText
        setCurrentDate();

        dateEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addPatient();
            }
        });

        fetchPatients();
    }

    private void setCurrentDate() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        dateEditText.setText(day + "/" + (month + 1) + "/" + year);
    }

    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                AddPatientActivity.this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        dateEditText.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                    }
                },
                year, month, day);
        datePickerDialog.show();
    }

    private void addPatient() {
        final String patientId = idEditText.getText().toString();
        final String name = nameEditText.getText().toString();
        final String age = ageEditText.getText().toString();
        final String date = dateEditText.getText().toString();
        final String address = addressEditText.getText().toString();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL("http://10.0.2.2/aaaaaaaaaaa/add_patient.php");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);

                    OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
                    writer.write("patient_id=" + patientId + "&name=" + name + "&age=" + age + "&date=" + date + "&address=" + address);
                    writer.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    final StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    reader.close();
                    writer.close();
                    conn.disconnect();

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            fetchPatients();
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void fetchPatients() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL("http://10.0.2.2/aaaaaaaaaaa//get_patients.php");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    final StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    reader.close();
                    conn.disconnect();

                    final JSONArray patients = new JSONArray(response.toString());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            StringBuilder patientsText = new StringBuilder();
                            for (int i = 0; i < patients.length(); i++) {
                                JSONObject patient = null;
                                try {
                                    patient = patients.getJSONObject(i);
                                } catch (JSONException e) {
                                    throw new RuntimeException(e);
                                }
                                try {
                                    patientsText.append("ID: ").append(patient.getInt("patient_id")).append("\n");
                                } catch (JSONException e) {
                                    throw new RuntimeException(e);
                                }
                                try {
                                    patientsText.append("Name: ").append(patient.getString("name")).append("\n");
                                } catch (JSONException e) {
                                    throw new RuntimeException(e);
                                }
                                try {
                                    patientsText.append("Age: ").append(patient.getInt("age")).append("\n");
                                } catch (JSONException e) {
                                    throw new RuntimeException(e);
                                }
                                try {
                                    patientsText.append("Date: ").append(patient.getString("date")).append("\n");
                                } catch (JSONException e) {
                                    throw new RuntimeException(e);
                                }
                                try {
                                    patientsText.append("Address: ").append(patient.getString("address")).append("\n\n");
                                } catch (JSONException e) {
                                    throw new RuntimeException(e);
                                }
                            }
                            patientListTextView.setText(patientsText.toString());
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
