// MainActivity.java
package com.example.myapp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ReportsActivity extends AppCompatActivity {

    private EditText editTextPatientId;
    private Button buttonGenerateInvoice;
    private TextView textViewResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        editTextPatientId = findViewById(R.id.editTextPatientId);
        buttonGenerateInvoice = findViewById(R.id.buttonGenerateInvoice);
        textViewResult = findViewById(R.id.textViewResult);

        buttonGenerateInvoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String patientId = editTextPatientId.getText().toString().trim();
                if (!patientId.isEmpty()) {
                    generateInvoice(patientId);
                } else {
                    Toast.makeText(ReportsActivity.this, "Please enter Patient ID", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void generateInvoice(String patientId) {
        String url = "http://10.0.2.2/aaaaaaaaaaa/generate_invoice.php?patient_id=" + patientId;
        new GenerateInvoiceTask().execute(url);
    }

    private class GenerateInvoiceTask extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            textViewResult.setText("Generating Invoice...");
        }

        @Override
        protected String doInBackground(String... params) {
            String url = params[0];
            String response = "";
            try {
                URL urlObj = new URL(url);
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setRequestMethod("GET");

                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String inputLine;
                StringBuilder content = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    content.append(inputLine);
                }
                in.close();

                response = content.toString();
                conn.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
                response = "Error: " + e.getMessage();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            textViewResult.setText(result);
        }
    }
}
