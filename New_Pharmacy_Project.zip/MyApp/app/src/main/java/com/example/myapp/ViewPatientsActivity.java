package com.example.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myapp.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class ViewPatientsActivity extends AppCompatActivity {

    EditText etName, etQuantity, etPrice, etExpiryDate;
    Button btnAddMedicine;
    ListView lvMedicines;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_patients);

        etName = findViewById(R.id.etName);
        etQuantity = findViewById(R.id.etQuantity);
        etPrice = findViewById(R.id.etPrice);
        etExpiryDate = findViewById(R.id.etExpiryDate);
        btnAddMedicine = findViewById(R.id.btnAddMedicine);
        lvMedicines = findViewById(R.id.lvMedicines);

        btnAddMedicine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString();
                String quantity = etQuantity.getText().toString();
                String price = etPrice.getText().toString();
                String expiryDate = etExpiryDate.getText().toString();

                new AddMedicineTask().execute(name, quantity, price, expiryDate);
            }
        });

        new FetchMedicinesTask().execute();
    }

    private class AddMedicineTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String name = params[0];
            String quantity = params[1];
            String price = params[2];
            String expiryDate = params[3];

            try {
                URL url = new URL("http://10.0.2.2/aaaaaaaaaaa/add_medicine.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);

                String postData = "name=" + name + "&quantity=" + quantity + "&price=" + price + "&expiry_date=" + expiryDate;
                OutputStream os = conn.getOutputStream();
                os.write(postData.getBytes());
                os.flush();
                os.close();

                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                return response.toString();
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(ViewPatientsActivity.this, result, Toast.LENGTH_LONG).show();
            new FetchMedicinesTask().execute(); // Refresh the list after adding a new medicine
        }
    }

    private class FetchMedicinesTask extends AsyncTask<Void, Void, ArrayList<String>> {
        @Override
        protected ArrayList<String> doInBackground(Void... voids) {
            ArrayList<String> medicines = new ArrayList<>();

            try {
                URL url = new URL("http://10.0.2.2/aaaaaaaaaaa/fetch_medicines.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                JSONArray jsonArray = new JSONArray(response.toString());
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String name = jsonObject.getString("name");
                    int quantity = jsonObject.getInt("quantity");
                    double price = jsonObject.getDouble("price");
                    String expiryDate = jsonObject.getString("expiry_date");
                    medicines.add(name + " - " + quantity + " - " + price + " - " + expiryDate);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            return medicines;
        }

        @Override
        protected void onPostExecute(ArrayList<String> result) {
            ArrayAdapter<String> adapter = new ArrayAdapter<>(ViewPatientsActivity.this, android.R.layout.simple_list_item_1, result);
            lvMedicines.setAdapter(adapter);
        }
    }
}
