package com.example.myapp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class StocksActivity extends AppCompatActivity {

    private EditText editTextPatientId;
    private Button buttonGenerateInvoice;
    private LinearLayout invoiceDetailsLayout;
    private LinearLayout medicineDetailsLayout;
    private TextView textViewPatientId;
    private TextView textViewTotalAmount;
    private CheckBox checkBoxPaid;
    private Button buttonSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stocksactivity);

        editTextPatientId = findViewById(R.id.editTextPatientId);
        buttonGenerateInvoice = findViewById(R.id.buttonGenerateInvoice);
        invoiceDetailsLayout = findViewById(R.id.invoiceDetailsLayout);
        medicineDetailsLayout = findViewById(R.id.medicineDetailsLayout);
        textViewPatientId = findViewById(R.id.textViewPatientId);
        textViewTotalAmount = findViewById(R.id.textViewTotalAmount);
        checkBoxPaid = findViewById(R.id.checkBoxPaid);
        buttonSave = findViewById(R.id.buttonSave);

        buttonGenerateInvoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String patientId = editTextPatientId.getText().toString().trim();
                if (!patientId.isEmpty()) {
                    generateInvoice(patientId);
                } else {
                    Toast.makeText(StocksActivity.this, "Please enter Patient ID", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement save functionality here
                boolean isPaid = checkBoxPaid.isChecked();
                if (isPaid) {
                    Toast.makeText(StocksActivity.this, "Invoice saved as paid", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(StocksActivity.this, "Invoice saved", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void generateInvoice(String patientId) {
        String url = "http://10.0.2.2/aaaaaaaaaaa/generate_invoice.php?patient_id=" + patientId;
        new GenerateInvoiceTask().execute(url);
    }

    private class GenerateInvoiceTask extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Clear existing invoice details
            invoiceDetailsLayout.removeAllViews();
            medicineDetailsLayout.removeAllViews();
            // Show loading or progress indicator if needed
        }

        @Override
        protected String doInBackground(String... params) {
            String url = params[0];
            String response = "";
            try {
                URL urlObj = new URL(url);
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setRequestMethod("GET");

                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String inputLine;
                StringBuilder content = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    content.append(inputLine);
                }
                in.close();

                response = content.toString();
                conn.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
                response = "Error: " + e.getMessage();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Log.d("TAG", "Raw JSON Response: " + result); // Debugging log

            try {
                JSONObject jsonObject = new JSONObject(result);

                // Example: Extracting invoice details
                String patientId = jsonObject.getString("patient_id");
                String patientName = jsonObject.getString("patient_name");
                String invoiceDate = jsonObject.getString("invoice_date");
                String totalAmount = jsonObject.getString("total_amount");

                // Update UI with invoice details
                textViewPatientId.setText("Patient ID: " + patientId);
                textViewTotalAmount.setText("Total Amount: $" + totalAmount);

                // Example: Fetching and displaying medicine details
                if (jsonObject.has("medicines")) {
                    JSONArray medicinesArray = jsonObject.getJSONArray("medicines");
                    for (int i = 0; i < medicinesArray.length(); i++) {
                        JSONObject medicineObject = medicinesArray.getJSONObject(i);
                        String medicineName = medicineObject.getString("name");
                        String amount = medicineObject.getString("amount");

                        // Create TextViews to display medicine details
                        TextView tvMedicine = new TextView(StocksActivity.this);
                        tvMedicine.setText("Medicine: " + medicineName + ", Amount: $" + amount);
                        medicineDetailsLayout.addView(tvMedicine);
                    }
                } else {
                    Toast.makeText(StocksActivity.this, "No medicines found", Toast.LENGTH_SHORT).show();
                }

            } catch (JSONException e) {
                e.printStackTrace();
                Toast.makeText(StocksActivity.this, "Error parsing JSON: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(StocksActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }
}
